package edu.illinois.imunit.internal.parsing;

public class Ordering {

    private Event beforeEvent;

    private SimpleEvent afterEvent;

    public Ordering(Event beforeEvent, SimpleEvent afterEvent) {
        this.beforeEvent = beforeEvent;
        this.afterEvent = afterEvent;
    }

    public Event getBeforeEvent() {
        return beforeEvent;
    }

    public SimpleEvent getAfterEvent() {
        return afterEvent;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((afterEvent == null) ? 0 : afterEvent.hashCode());
        result = prime * result + ((beforeEvent == null) ? 0 : beforeEvent.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Ordering other = (Ordering) obj;
        if (afterEvent == null) {
            if (other.afterEvent != null)
                return false;
        } else if (!afterEvent.equals(other.afterEvent))
            return false;
        if (beforeEvent == null) {
            if (other.beforeEvent != null)
                return false;
        } else if (!beforeEvent.equals(other.beforeEvent))
            return false;
        return true;
    }

}
