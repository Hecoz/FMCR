package edu.illinois.imunit;

import java.io.StringReader;
import java.lang.Thread.State;
import java.lang.Thread.UncaughtExceptionHandler;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunNotifier;
import org.junit.runners.BlockJUnit4ClassRunner;
import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.InitializationError;

import edu.illinois.imunit.internal.parsing.Orderings;
import edu.illinois.imunit.internal.parsing.ParseException;
import edu.illinois.imunit.internal.parsing.ScheduleParser;
import edu.illinois.imunit.internal.parsing.TokenMgrError;

/**
 * Custom JUnit runner for IMUnit.
 * 
 * @author Vilas Jagannath (vbangal2@illinois.edu), <br/>
 *         Milos Gligoric (gliga@illinois.edu), <br/>
 *         Dongyun Jin (djin3@illinois.edu), <br/>
 *         Qingzhou Luo (qluo2@illinois.edu).
 */
public class IMUnitRunner extends BlockJUnit4ClassRunner {

    /**
     * Constants
     */
    private static final String GROUP_NAME = "imunit-thread-group";
    private static final String MAIN_THREAD_NAME = "main";
    private static final String INVALID_SYNTAX_MESSAGE = "Ignoring schedule because of invalid syntax: name = %s value = %s .\nCaused by: %s";
    private static final String TERMINATION_DETECTION_THREAD_INTERRUPTED_MSG = "Termination detection thread was interrupted!";
    private static final String DEADLOCK_DETECTED_MSG = "Deadlock detected!%s\nFollowing threads were unable to make progress: %s";
    private static final String UNENCOUNTERED_AFTER_EVENTS_MSG = "The following events were not encountered: %s";
    private static final String COMMA_SEP = ", ";
    private static final String WAITING_THREAD_MSG = "\nThread named: %s, was waiting for event: %s";

    /**
     * Currently executing test method and notifier and schedule.
     */
    private FrameworkMethod currentTestMethod;
    private RunNotifier currentTestNotifier;
    private String currentSchedule;

    /**
     * Creates an {@link IMUnitRunner} for the given test class.
     * 
     * @param klass
     * @throws InitializationError
     */
    public IMUnitRunner(Class<?> klass) throws InitializationError {
        super(klass);
        /* Log any uncaught exceptions in child threads */
        Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                currentTestNotifier.fireTestFailure(new Failure(describeChild(currentTestMethod), e));
            }
        });
    }

    /**
     * Collects the schedules specified for each test method and runs the test method for each specified schedule, while
     * enforcing that schedule.
     */
    @Override
    protected void runChild(final FrameworkMethod method, final RunNotifier notifier) {
        this.currentTestMethod = method;
        this.currentTestNotifier = notifier;
        Map<String, Orderings> schedules = collectSchedules();

        if (!schedules.isEmpty()) {
            for (Entry<String, Orderings> schedule : schedules.entrySet()) {
                currentSchedule = schedule.getKey();
                IMUnit.setSchedule(currentSchedule, schedule.getValue());
                /*
                 * Create a separate thread group and thread within that group to run the imunit test
                 */
                ThreadGroup imunitGroup = new ThreadGroup(GROUP_NAME);
                Runnable imunitRunnable = new Runnable() {
                    @Override
                    public void run() {
                        IMUnitRunner.super.runChild(method, notifier);
                    }
                };
                Thread imunitThread = new Thread(imunitGroup, imunitRunnable, MAIN_THREAD_NAME);

                /* Start the imunit thread and the termination detection thread */
                imunitThread.start();
                Thread terminationDetectionThread = new Thread(new TerminationDetector(imunitGroup, imunitThread));
                terminationDetectionThread.setDaemon(true);
                terminationDetectionThread.start();

                /* Wait for the termination detection thread to terminate */
                try {
                    terminationDetectionThread.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    System.exit(2);
                }
            }
            IMUnit.clearSchedule();
        } else {
            super.runChild(method, notifier);
        }
    }

    /**
     * Helper method for collecting all the name and partial orders for the given test method.
     */
    private Map<String, Orderings> collectSchedules() {
        Map<String, Orderings> schedules = new HashMap<String, Orderings>();
        Schedules schsAnno = this.currentTestMethod.getAnnotation(Schedules.class);
        if (schsAnno != null) {
            for (Schedule schAnno : schsAnno.value()) {
                collectSchedule(schAnno, schedules);
            }
        }
        Schedule schAnno = currentTestMethod.getAnnotation(Schedule.class);
        if (schAnno != null) {
            collectSchedule(schAnno, schedules);
        }
        return schedules;
    }

    /**
     * Helper method for collecting the name and partial orders from each {@link Schedule} annotation.
     * 
     * @param schAnno
     * @param schedules
     * 
     */
    private void collectSchedule(Schedule schAnno, Map<String, Orderings> schedules) {
        String schName = schAnno.name();
        schName = schName != null && schName.length() > 0 ? schName : schAnno.value();
        try {
            schedules.put(schName, new ScheduleParser(new StringReader(schAnno.value())).Orderings());
        } catch (ParseException e) {
            this.currentTestNotifier.fireTestFailure(new Failure(describeChild(this.currentTestMethod), new ScheduleError(schName, String.format(
                    INVALID_SYNTAX_MESSAGE, schName, schAnno.value(), e))));
        } catch (TokenMgrError e) {
            this.currentTestNotifier.fireTestFailure(new Failure(describeChild(this.currentTestMethod), new ScheduleError(schName, String.format(
                    INVALID_SYNTAX_MESSAGE, schName, schAnno.value(), e))));
        }
    }

    /**
     * Class that detects termination of a thread group either normally or via a deadlock.
     * 
     * @author Vilas
     */
    final class TerminationDetector implements Runnable {

        private final Thread main;
        private final ThreadGroup group;

        /**
         * @param group
         *            {@link ThreadGroup} within which to detect normal termination or deadlocks.
         * 
         * @param main
         *            Main {@link Thread} in the {@link ThreadGroup}, the termination of which signals the termination
         *            of the entire {@link ThreadGroup}.
         */
        public TerminationDetector(ThreadGroup group, Thread main) {
            this.main = main;
            this.group = group;
        }

        @Override
        public void run() {
            /* Run while the main thread has not terminated */
            while (!main.getState().equals(State.TERMINATED)) {
                /* Sleep for a while */
                try {
                    Thread.sleep(30);
                } catch (InterruptedException e) {
                    System.err.println(TERMINATION_DETECTION_THREAD_INTERRUPTED_MSG);
                    e.printStackTrace();
                }
                /* If all active threads are blocked/waiting its a deadlock */
                Thread[] activeThreads = new Thread[group.activeCount()];
                int numInArray = group.enumerate(activeThreads);
                if (numInArray == activeThreads.length && numInArray > 0) {
                    boolean deadlock = true;
                    for (int i = 0; i < activeThreads.length; i++) {
                        State activeState = activeThreads[i].getState();
                        if (activeState != State.BLOCKED && activeState != State.WAITING) {
                            deadlock = false;
                            break;
                        }
                    }
                    if (deadlock) {
                        String deadlockMessage = String.format(DEADLOCK_DETECTED_MSG, getWaitingThreadsList(IMUnit.getWaitingThreads()),
                                getThreadsList(activeThreads));
                        ScheduleError scheduleError = new ScheduleError(currentSchedule, deadlockMessage);
                        currentTestNotifier.fireTestFailure(new Failure(describeChild(currentTestMethod), scheduleError));
                        break;
                    }
                }
            }
            /* Terminated normally. Report a failure if any after-events were not encountered */
            Set<String> unencounteredAfterEvents = IMUnit.getOrderings().keySet();
            unencounteredAfterEvents.removeAll(IMUnit.getHappenedEvents().keySet());
            if (!unencounteredAfterEvents.isEmpty()) {
                String unencounteredEventsMessage = String.format(UNENCOUNTERED_AFTER_EVENTS_MSG, getEventsList(unencounteredAfterEvents));
                ScheduleError scheduleError = new ScheduleError(currentSchedule, unencounteredEventsMessage);
                currentTestNotifier.fireTestFailure(new Failure(describeChild(currentTestMethod), scheduleError));
            }
        }

        private String getWaitingThreadsList(Map<Thread, String> waitingThreads) {
            StringBuffer list = new StringBuffer();
            for (Entry<Thread, String> waitingThread : waitingThreads.entrySet()) {
                list.append(String.format(WAITING_THREAD_MSG, waitingThread.getKey().getName(), waitingThread.getValue()));
            }
            return list.toString();
        }

        private String getThreadsList(Thread[] threads) {
            StringBuffer list = new StringBuffer();
            for (Thread thread : threads) {
                list.append(thread.getName());
                list.append(COMMA_SEP);
            }
            return list.substring(0, list.lastIndexOf(COMMA_SEP));
        }

        private String getEventsList(Set<String> events) {
            StringBuffer list = new StringBuffer();
            for (String event : events) {
                list.append(event);
                list.append(COMMA_SEP);
            }
            return list.substring(0, list.lastIndexOf(COMMA_SEP));
        }
    }

}
